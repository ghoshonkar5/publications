import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { GitamLogo } from "./GitamLogo";
import { User, BookOpen, Link, Camera, ArrowRight, CheckCircle, Plus, X } from "lucide-react";
import { useAuth } from "./AuthContext";

// ── Compress image (same as EditProfile) ─────────────────────────
const compressImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (file.size > 5 * 1024 * 1024) {
      reject(new Error('Image must be under 5MB'));
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX = 200;
        let { width, height } = img;
        if (width > height) {
          if (width > MAX) { height = Math.round(height * MAX / width); width = MAX; }
        } else {
          if (height > MAX) { width = Math.round(width * MAX / height); height = MAX; }
        }
        canvas.width = width; canvas.height = height;
        const ctx = canvas.getContext('2d')!;
        ctx.drawImage(img, 0, 0, width, height);
        const base64 = canvas.toDataURL('image/jpeg', 0.75);
        resolve(base64.length > 200000 ? canvas.toDataURL('image/jpeg', 0.5) : base64);
      };
      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
};

function InitialsAvatar({ name }: { name?: string }) {
  const initials = (name || 'FA').split(' ').filter(Boolean).slice(0, 3).map(w => w[0].toUpperCase()).join('');
  return (
    <div className="w-20 h-20 rounded-full flex items-center justify-center font-semibold text-white text-xl"
      style={{ background: 'linear-gradient(135deg, #006B64 0%, #005A54 100%)' }}>
      {initials}
    </div>
  );
}

// ── Reusable tag input with + / × ────────────────────────────────
function TagInput({ label, items, onChange, placeholder }: {
  label: string;
  items: string[];
  onChange: (items: string[]) => void;
  placeholder: string;
}) {
  const [inputVal, setInputVal] = useState('');

  const add = () => {
    const trimmed = inputVal.trim();
    if (trimmed && !items.includes(trimmed)) onChange([...items, trimmed]);
    setInputVal('');
  };

  const remove = (index: number) => onChange(items.filter((_, i) => i !== index));

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') { e.preventDefault(); add(); }
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>
      {items.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-2">
          {items.map((item, i) => (
            <span key={i} className="flex items-center gap-1 bg-teal-50 border border-teal-200 text-teal-800 text-sm rounded-lg px-3 py-1">
              {item}
              <button type="button" onClick={() => remove(i)}
                className="ml-1 text-teal-400 hover:text-red-500 transition-colors">
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>
      )}
      <div className="flex gap-2">
        <input type="text" value={inputVal} onChange={e => setInputVal(e.target.value)}
          onKeyDown={handleKey} placeholder={placeholder}
          className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 bg-white" />
        <button type="button" onClick={add} disabled={!inputVal.trim()}
          className="flex items-center gap-1 px-3 py-2 rounded-lg text-sm text-white transition-colors disabled:opacity-40"
          style={{ backgroundColor: '#006B64' }}>
          <Plus className="w-4 h-4" />Add
        </button>
      </div>
    </div>
  );
}

export function ProfileSetup() {
  const navigate = useNavigate();
  const { user, saveExtendedProfile, updateProfileUrls, updateProfile } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [saving, setSaving] = useState(false);
  const [skipping, setSkipping] = useState(false);
  const [error, setError] = useState('');
  const [photoError, setPhotoError] = useState('');

  // Tag list states
  const [coursesList, setCoursesList] = useState<string[]>([]);
  const [rolesList, setRolesList] = useState<string[]>([]);

  const [form, setForm] = useState({
    mobile: user?.mobile || '',
    officeRoom: '',
    yearsOfExperience: '',
    officeHours: '',
    linkedinUrl: '',
    websiteUrl: '',
    googleScholarUrl: '',
    scopusUrl: '',
    wosUrl: '',
    profilePhoto: '',
  });

  const set = (field: string, value: string) =>
    setForm(prev => ({ ...prev, [field]: value }));

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoError('');
    try {
      const compressed = await compressImage(file);
      set('profilePhoto', compressed);
    } catch (err: any) {
      setPhotoError(err.message || 'Failed to process image');
    }
    e.target.value = '';
  };

  const handleSkip = async () => {
    setSkipping(true);
    // Just mark profile setup complete, don't save any data
    await updateProfile({ profileSetupComplete: true, isFirstTimeLogin: false });
    setSkipping(false);
    // App.tsx will redirect to dashboard via user state change
  };

  const handleSave = async () => {
    setSaving(true);
    setError('');
    try {
      const profileResult = await saveExtendedProfile({
        mobile: form.mobile || null,
        officeRoom: form.officeRoom || null,
        yearsOfExperience: form.yearsOfExperience ? parseInt(form.yearsOfExperience) : null,
        coursesTaught: coursesList.join(', ') || null,
        officeHours: form.officeHours || null,
        roles: rolesList.join(', ') || null,
        linkedinUrl: form.linkedinUrl || null,
        websiteUrl: form.websiteUrl || null,
        profilePhoto: form.profilePhoto || null,
      });

      if (!profileResult.success) {
        setError(profileResult.error || 'Failed to save profile');
        return;
      }

      if (form.googleScholarUrl || form.scopusUrl || form.wosUrl) {
        await updateProfileUrls({
          googleScholarUrl: form.googleScholarUrl,
          scopusUrl: form.scopusUrl,
          wosUrl: form.wosUrl,
        });
      }

      // App.tsx will redirect to dashboard via user state change
    } catch (err: any) {
      setError(err.message || 'Failed to save profile');
    } finally {
      setSaving(false);
    }
  };

  const inputClass = "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 bg-white";
  const labelClass = "block text-sm font-medium text-gray-700 mb-1";

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-emerald-50 to-green-50">
      {/* Header */}
      <header style={{ backgroundColor: '#006B64', borderBottomLeftRadius: '24px', borderBottomRightRadius: '24px' }} className="shadow-md overflow-hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-center h-16">
          <div className="flex items-center gap-3">
            <GitamLogo className="w-8 h-8" />
            <h1 className="text-base font-semibold text-white">Complete Your Profile</h1>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">

        {/* Welcome banner */}
        <div className="text-center mb-2">
          <h2 className="text-2xl font-semibold text-gray-900 mb-1">
            Welcome to GITAM Research Portal, {user?.name?.split(' ')[0]}! 👋
          </h2>
          <p className="text-gray-500 text-sm">
            Set up your profile so colleagues and admin can see your details. You can skip this and do it later from Settings.
          </p>
        </div>

        {/* Profile Photo */}
        <Card className="bg-white/95 shadow-lg border-0 rounded-xl">
          <CardHeader className="text-white rounded-t-xl" style={{ background: "linear-gradient(135deg, #006B64 0%, #005A54 100%)" }}>
            <CardTitle className="flex items-center space-x-2 text-white">
              <User className="w-5 h-5" />
              <span>Profile Photo & Identity</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 flex items-center gap-6">
            <div className="relative flex-shrink-0">
              {form.profilePhoto ? (
                <img src={form.profilePhoto} alt="Profile"
                  className="w-20 h-20 rounded-full object-cover border-4 border-teal-100" />
              ) : (
                <InitialsAvatar name={user?.name} />
              )}
              <button onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-teal-600 hover:bg-teal-700 flex items-center justify-center shadow-md">
                <Camera className="w-3.5 h-3.5 text-white" />
              </button>
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
            </div>
            <div>
              <p className="font-semibold text-gray-900">{user?.name}</p>
              <p className="text-sm text-gray-500">{user?.designation} · {user?.department}</p>
              <p className="text-xs text-gray-400 mt-1">Click camera icon to upload (max 5MB)</p>
              {photoError && <p className="text-xs text-red-500 mt-1">{photoError}</p>}
              {form.profilePhoto && (
                <button onClick={() => set('profilePhoto', '')}
                  className="text-xs text-red-500 hover:text-red-700 mt-1 underline">Remove photo</button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Personal & Academic */}
        <Card className="bg-white/95 shadow-lg border-0 rounded-xl">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2" style={{ color: "#006B64" }}>
              <BookOpen className="w-5 h-5" />
              <span>Personal & Academic Details</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>Mobile Number</label>
              <input type="tel" className={inputClass} placeholder="+91-9876543210"
                value={form.mobile} onChange={e => set('mobile', e.target.value)} />
            </div>
            <div>
              <label className={labelClass}>Office Room</label>
              <input type="text" className={inputClass} placeholder="e.g. CSE-Block, Room 301"
                value={form.officeRoom} onChange={e => set('officeRoom', e.target.value)} />
            </div>
            <div>
              <label className={labelClass}>Years of Experience</label>
              <input type="number" className={inputClass} placeholder="e.g. 8" min="0" max="50"
                value={form.yearsOfExperience} onChange={e => set('yearsOfExperience', e.target.value)} />
            </div>
            <div>
              <label className={labelClass}>Office Hours</label>
              <div className="flex flex-wrap gap-2 items-center">
                <select
                  value={form.officeHours.split(',')[0]?.split(' ')[0] || ''}
                  onChange={e => {
                    const parts = form.officeHours.split(', ');
                    const timePart = parts[1] || '9:00 AM - 5:00 PM';
                    set('officeHours', `${e.target.value}, ${timePart}`);
                  }}
                  className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-500 bg-white"
                >
                  <option value="">Select days</option>
                  <option value="Mon-Fri">Mon – Fri</option>
                  <option value="Mon-Sat">Mon – Sat</option>
                  <option value="Mon-Wed">Mon – Wed</option>
                  <option value="Thu-Fri">Thu – Fri</option>
                  <option value="Mon">Monday only</option>
                  <option value="Tue">Tuesday only</option>
                  <option value="Wed">Wednesday only</option>
                  <option value="Thu">Thursday only</option>
                  <option value="Fri">Friday only</option>
                </select>
                <input
                  type="time"
                  value={(() => {
                    const t = form.officeHours.split(', ')[1]?.split(' - ')[0];
                    if (!t) return '';
                    const [time, ampm] = t.split(' ');
                    let [h, m] = time.split(':').map(Number);
                    if (ampm === 'PM' && h !== 12) h += 12;
                    if (ampm === 'AM' && h === 12) h = 0;
                    return `${String(h).padStart(2,'0')}:${String(m||0).padStart(2,'0')}`;
                  })()}
                  onChange={e => {
                    const [h, m] = e.target.value.split(':').map(Number);
                    const ampm = h >= 12 ? 'PM' : 'AM';
                    const h12 = h % 12 || 12;
                    const fromStr = `${h12}:${String(m).padStart(2,'0')} ${ampm}`;
                    const dayPart = form.officeHours.split(', ')[0] || 'Mon-Fri';
                    const toPart = form.officeHours.split(' - ')[1] || '5:00 PM';
                    set('officeHours', `${dayPart}, ${fromStr} - ${toPart}`);
                  }}
                  className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-500 bg-white"
                />
                <span className="text-gray-400 text-sm">to</span>
                <input
                  type="time"
                  value={(() => {
                    const t = form.officeHours.split(' - ')[1];
                    if (!t) return '';
                    const [time, ampm] = t.trim().split(' ');
                    let [h, m] = time.split(':').map(Number);
                    if (ampm === 'PM' && h !== 12) h += 12;
                    if (ampm === 'AM' && h === 12) h = 0;
                    return `${String(h).padStart(2,'0')}:${String(m||0).padStart(2,'0')}`;
                  })()}
                  onChange={e => {
                    const [h, m] = e.target.value.split(':').map(Number);
                    const ampm = h >= 12 ? 'PM' : 'AM';
                    const h12 = h % 12 || 12;
                    const toStr = `${h12}:${String(m).padStart(2,'0')} ${ampm}`;
                    const fromPart = form.officeHours.split(' - ')[0] || 'Mon-Fri, 9:00 AM';
                    set('officeHours', `${fromPart} - ${toStr}`);
                  }}
                  className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-500 bg-white"
                />
              </div>
              {form.officeHours && (
                <p className="text-xs text-teal-600 mt-1">📅 {form.officeHours}</p>
              )}
            </div>
            <div className="md:col-span-2">
              <TagInput
                label="Courses Taught"
                items={coursesList}
                onChange={setCoursesList}
                placeholder="e.g. Data Structures"
              />
            </div>
            <div className="md:col-span-2">
              <TagInput
                label="Roles & Responsibilities"
                items={rolesList}
                onChange={setRolesList}
                placeholder="e.g. Class Coordinator - CSE 3rd Year"
              />
            </div>
          </CardContent>
        </Card>

        {/* Links */}
        <Card className="bg-white/95 shadow-lg border-0 rounded-xl">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2" style={{ color: "#006B64" }}>
              <Link className="w-5 h-5" />
              <span>Professional Links <span className="text-sm font-normal text-gray-400">(optional)</span></span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>LinkedIn URL</label>
              <input type="url" className={inputClass} placeholder="https://linkedin.com/in/yourprofile"
                value={form.linkedinUrl} onChange={e => set('linkedinUrl', e.target.value)} />
            </div>
            <div>
              <label className={labelClass}>Personal Website</label>
              <input type="url" className={inputClass} placeholder="https://yourwebsite.com"
                value={form.websiteUrl} onChange={e => set('websiteUrl', e.target.value)} />
            </div>
            <div>
              <label className={labelClass}><span className="inline-block w-2.5 h-2.5 rounded-full bg-orange-400 mr-1"></span>Google Scholar URL</label>
              <input type="url" className={inputClass} placeholder="https://scholar.google.com/citations?user=..."
                value={form.googleScholarUrl} onChange={e => set('googleScholarUrl', e.target.value)} />
            </div>
            <div>
              <label className={labelClass}><span className="inline-block w-2.5 h-2.5 rounded-full bg-blue-400 mr-1"></span>Scopus URL</label>
              <input type="url" className={inputClass} placeholder="https://www.scopus.com/authid/detail.uri?authorId=..."
                value={form.scopusUrl} onChange={e => set('scopusUrl', e.target.value)} />
            </div>
            <div className="md:col-span-2">
              <label className={labelClass}><span className="inline-block w-2.5 h-2.5 rounded-full bg-green-400 mr-1"></span>Web of Science URL</label>
              <input type="url" className={inputClass} placeholder="https://www.webofscience.com/wos/author/record/..."
                value={form.wosUrl} onChange={e => set('wosUrl', e.target.value)} />
            </div>
          </CardContent>
        </Card>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700">{error}</div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-between items-center pb-8">
          <Button variant="outline" onClick={handleSkip} disabled={skipping || saving}
            className="border-gray-300 text-gray-500 hover:bg-gray-50">
            {skipping ? 'Skipping...' : 'Skip for now'}
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
          <Button onClick={handleSave} disabled={saving || skipping}
            className="text-white px-8" style={{ backgroundColor: "#006B64" }}>
            {saving ? (
              <><CheckCircle className="w-4 h-4 mr-2 animate-pulse" />Saving...</>
            ) : (
              <>Save & Go to Dashboard<ArrowRight className="w-4 h-4 ml-2" /></>
            )}
          </Button>
        </div>
      </main>
    </div>
  );
}