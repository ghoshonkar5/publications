const express = require('express');
const router = express.Router();
const { login, register, getMe, updateProfile, updateProfileUrls, getAllFaculty, adminUpdateFaculty } = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware');

// Public routes
router.post('/login', login);
router.post('/register', register);

// Protected routes
router.get('/me', protect, getMe);
router.put('/profile', protect, updateProfile);
router.put('/profile-urls', protect, updateProfileUrls);
router.get('/faculty', protect, getAllFaculty);

// ✅ Admin — update any faculty profile
router.put('/admin/faculty/:id', protect, adminUpdateFaculty);

module.exports = router;